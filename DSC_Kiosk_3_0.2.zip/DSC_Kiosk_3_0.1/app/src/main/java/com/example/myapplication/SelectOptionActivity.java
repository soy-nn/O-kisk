package com.example.myapplication;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SelectOptionActivity extends AppCompatActivity {

    private boolean btnContainClicked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_option);

        // 옵션1의 LinearLayout ID
        final int option1Id = R.id.option1;
        // 옵션2의 LinearLayout ID
        final int option2Id = R.id.option2;

        // 옵션1의 LinearLayout을 찾아서 클릭 이벤트 처리
        LinearLayout option1Layout = findViewById(option1Id);
        option1Layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 옵션1 클릭 이벤트 처리 코드 추가
                changeOptionImageBackground(R.id.optionImage1);
            }
        });

        // 옵션2의 LinearLayout을 찾아서 클릭 이벤트 처리
        LinearLayout option2Layout = findViewById(option2Id);
        option2Layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 옵션2 클릭 이벤트 처리 코드 추가
                changeOptionImageBackground(R.id.optionImage2);
            }
        });

        //장바구니 버튼 감지
        Button btnContain = findViewById(R.id.btnContain);

        btnContain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // btnContain이 클릭되었음을 플래그로 표시
                Intent intent = new Intent(SelectOptionActivity.this, SelectDetailActivity.class);
                intent.putExtra("btnContainClicked", true);
                startActivity(intent);
            }
        });



    }
    // getter 메서드 추가
    public boolean isBtnContainClicked() {
        return btnContainClicked;
    }
    // 플래그 초기화 함수
    public void resetBtnContainClicked() {
        btnContainClicked = false;
    }
    // 옵션Image의 배경 색을 변경하는 메서드
    private void changeOptionImageBackground(int selectedOptionId) {
        // 선택한 옵션Image의 Drawable 가져오기
        Drawable selectedOptionDrawable = getResources().getDrawable(R.drawable.option_select);

        // 선택한 옵션Image의 배경 색 변경
        TextView selectedOptionText = findViewById(selectedOptionId);
        selectedOptionText.setBackground(selectedOptionDrawable);
    }
}