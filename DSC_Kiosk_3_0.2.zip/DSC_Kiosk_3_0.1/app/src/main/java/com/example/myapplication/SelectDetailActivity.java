package com.example.myapplication;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SelectDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_detail);

        //뒤로가기
        Button btnBack = (Button) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        //주문하기
        Button btnOrder = (Button) findViewById(R.id.btnOrder);

        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), OrderCheckActivity.class);
                startActivity(intent);
            }
        });

        //메뉴1번
        LinearLayout menuList1 = findViewById(R.id.menuList1);
        menuList1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SelectOptionActivity.class);
                startActivity(intent);

            }
        });


        // SelectOptionActivity에서 전달한 플래그 값을 얻어오기
        boolean btnContainClicked = getIntent().getBooleanExtra("btnContainClicked", false);

        if (btnContainClicked) {
            // btnContain이 클릭되었으면 UI 동적 추가 수행
            LinearLayout cartItemListLayout = findViewById(R.id.cartItemListLayout);
            View newItemView = LayoutInflater.from(this).inflate(R.layout.menu_item, null);
            cartItemListLayout.addView(newItemView);

            // SelectOptionActivity의 플래그 초기화 함수 호출
            SelectOptionActivity selectOptionActivity = new SelectOptionActivity();
            selectOptionActivity.resetBtnContainClicked();
        }

    }
}
